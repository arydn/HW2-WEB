import React from 'react';
import { ShapeType } from '../types/shapes';
import styles from '../styles/Sidebar.module.css';

interface SidebarProps {
  selected: ShapeType;
  onSelect: (shape: ShapeType) => void;
}

const shapeOptions: ShapeType[] = ['circle', 'square', 'triangle'];

const Sidebar: React.FC<SidebarProps> = ({ selected, onSelect }) => {
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, shape: ShapeType) => {
    e.dataTransfer.setData('shapeType', shape);
  };

  return (
    <div className={styles.sidebar}>
      {shapeOptions.map((shape) => (
        <div
          key={shape}
          className={`${styles.shapeIcon} ${styles[shape]} ${selected === shape ? styles.selected : ''}`}
          onClick={() => onSelect(shape)}
          draggable
          onDragStart={(e) => handleDragStart(e, shape)}
          title={shape}
        />
      ))}
    </div>
  );
};

export default Sidebar;
