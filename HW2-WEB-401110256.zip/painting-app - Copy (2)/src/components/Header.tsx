import React, { useRef, useState } from 'react';
import { useShapes } from '../context/ShapesContext';
import { Shape } from '../types/shapes';
import styles from '../styles/Header.module.css';

const Header = () => {
  const { shapes, setShapes } = useShapes();
  const [title, setTitle] = useState('Untitled Drawing');
  const [importedFileName, setImportedFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const exportShapes = () => {
    const dataStr = JSON.stringify(shapes, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const sanitizedTitle = title.trim().replace(/\s+/g, '-').toLowerCase();
    const filename = `${sanitizedTitle || 'untitled-drawing'}.json`;

    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const importedShapes: Shape[] = JSON.parse(reader.result as string);
        if (!Array.isArray(importedShapes)) throw new Error('Not an array');
        setShapes(importedShapes);
        setImportedFileName(file.name);
        alert(`✅ Imported ${file.name} successfully`);
      } catch (err) {
        alert(`❌ Failed to import ${file.name}: Invalid format`);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className={styles.header}>
      <input
        type="text"
        className={styles.titleInput}
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Untitled Drawing"
      />
      <div>
        <button onClick={exportShapes}>Export JSON</button>
        <button onClick={handleImportClick} style={{ marginLeft: '10px' }}>
          Import JSON
        </button>
        <input
          type="file"
          accept="application/json"
          ref={fileInputRef}
          onChange={handleImport}
          style={{ display: 'none' }}
        />
        {importedFileName && (
          <span style={{ marginLeft: '10px', fontSize: '0.9rem', color: '#444' }}>
            Imported: {importedFileName}
          </span>
        )}
      </div>
    </div>
  );
};

export default Header;
